# data_processor/core.py
# This module processes data, but it DEPENDS on the validator module.

# This is an internal import within the package.
# It will only work if the entire package is available (i.e., in the zip file).
from . import validator

def process_number(n):
    """Processes a number after validating it."""
    if validator.is_valid(n):
        return f"Processed valid number: {n}"
    else:
        return f"Error: Invalid number {n}"
