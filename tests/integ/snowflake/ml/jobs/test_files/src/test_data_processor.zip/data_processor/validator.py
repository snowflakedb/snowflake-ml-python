# data_processor/validator.py
# This module validates data.

MIN_VALUE = 0

def is_valid(num):
    """Checks if a number is positive."""
    return num > MIN_VALUE
